﻿namespace FluentFunctionalCoding
{
    public readonly struct Nothing
    {
        public static readonly Nothing SoftNull = new();
    }
}
